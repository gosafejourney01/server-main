import './App.scss';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header/Header';
import Auth from './pages/Auth/Auth';
import PrivateRoute from './PrivateRoute';
import Home from './pages/Home/Home';
import ResetPassword from './pages/ResetPassword/ResetPassword';

function App() {
  return (
    <Router>
      <div className="App">
        <div className="App__header">
          <Header />
          <div className="App__content">
            <Routes>
              <Route exact path="/auth" element={<Auth />} />
              <Route exact path="/" element={<PrivateRoute />}>
                <Route exact path="/" element={<Home />} />
              </Route>
              <Route exact path="/reset-password" element={<PrivateRoute />}>
                <Route exact path="/reset-password" element={<ResetPassword />} />
              </Route>
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
