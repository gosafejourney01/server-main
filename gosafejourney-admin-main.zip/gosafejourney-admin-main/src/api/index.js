import axios from 'axios';

const API = axios.create({ baseURL: process.env.REACT_APP_SERVER_URL });

API.interceptors.request.use((req) => {
  if (localStorage.getItem('profile')) {
    req.headers.Authorization = `Bearer ${JSON.parse(localStorage.getItem('profile')).token}`;
  }
  return req;
});

// User API
export const signIn = (formData) => API.post('/user/signin', formData);
export const signUp = (formData) => API.post('/user/signup', formData);
export const updateUser = (formData, userId) => API.patch(`/user/${userId}`, formData);
export const verify = (formData) => API.post('/user/verify', formData);

// Property API
export const createProperty = (formData) => API.post('/properties', formData);
export const getProperties = () => API.get('/properties');
export const updateProperty = (propertyId, formData) => API.patch(`/properties/${propertyId}`, formData);
export const fetchProperty = (propertyId) => API.get(`/properties/${propertyId}`);

// Admin API
export const getDetails = () => API.get('/admin/');
export const updateDetails = (formData) => API.patch('/admin/update', formData);

// Rooms API
export const getRoom = (formData) => API.post('/rooms/get', formData);

// Finance API
export const fetchFinance = (financeQuery) => API.get('/property-bookings/finance', { params: { ...financeQuery } });
