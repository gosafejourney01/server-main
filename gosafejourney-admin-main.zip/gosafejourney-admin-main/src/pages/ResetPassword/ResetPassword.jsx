import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast, Toaster } from 'react-hot-toast';
import './ResetPassword.scss';
import { updateUser } from '../../api';

function ResetPassword() {
  const [changePasswordData, setChangePasswordData] = useState({
    currPassword: '',
    newPassword: '',
    confirmNewPassword: '',
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setChangePasswordData({ ...changePasswordData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (changePasswordData.newPassword === changePasswordData.confirmNewPassword) {
        const profile = localStorage.getItem('profile');
        const { result } = JSON.parse(profile);
        const { _id } = result;
        const response = await updateUser({ newPassword: changePasswordData.newPassword, currentPassword: changePasswordData.currPassword }, _id);
        if (response.status === 200) {
          setLoading(false);
          navigate('/');
        }
      } else {
        setLoading(false);
        toast.error('Passwords do not match.');
      }
    } catch (error) {
      setLoading(false);
      toast.error('Current password is incorrect.');
    }
  };

  const goBackToDashboard = () => {
    navigate('/');
  };

  return (
    <div className="resetPassword">
      <form onSubmit={handleSubmit} className="resetPassword__content">
        <h3>Change Password</h3>
        <div className="resetPassword__card">
          <h4>
            Current password
            <span>*</span>
          </h4>
          <input name="currPassword" type="password" value={changePasswordData.currPassword} required onChange={handleChange} />
          <h4>
            New password
            <span>*</span>
          </h4>
          <input name="newPassword" type="password" value={changePasswordData.newPassword} required onChange={handleChange} />
          <h4>
            Confirm password
            <span>*</span>
          </h4>
          <input name="confirmNewPassword" type="password" value={changePasswordData.confirmNewPassword} required onChange={handleChange} />
        </div>
        <button className="resetPassword__continue" type="submit">
          {loading ? 'Loading...' : 'Change Password'}
        </button>
        <button className="resetPassword__goback" type="button" onClick={goBackToDashboard}>No. Go back.</button>
      </form>
      <Toaster />
    </div>
  );
}

export default ResetPassword;
