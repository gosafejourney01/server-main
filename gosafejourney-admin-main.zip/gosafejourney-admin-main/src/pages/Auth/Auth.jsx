import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { toast, Toaster } from 'react-hot-toast';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { signin, signup, verify } from '../../actions/auth';
import ContactDetailsCard from '../../components/AuthPage/ContactDetailsCard/ContactDetailsCard';
import CreatePasswordCard from '../../components/AuthPage/CreatePasswordCard/CreatePasswordCard';
import SignUpCard from '../../components/AuthPage/SignUpCard/SignUpCard';
import SignInCard from '../../components/AuthPage/SignInCard/SignInCard';
import OtpVerificationCard from '../../components/AuthPage/OtpVerificationCard/OtpVerificationCard';
import './Auth.scss';

function Auth() {
  const initialState = {
    firstName: '', lastName: '', email: '', phone: '', otp: '', password: '', confirmPassword: '',
  };

  const [signUp, setSignUp] = useState(false);
  const [signIn, setSignIn] = useState(true);
  const [contactDetails, setContactDetails] = useState(false);
  // eslint-disable-next-line no-unused-vars
  const [otpVerification, setOtpVerification] = useState(false);
  const [createPassword, setCreatePassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState(initialState);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const goBackToSignUp = () => {
    setContactDetails(false);
    setSignUp(true);
  };

  const goBackToContactDetails = () => {
    setContactDetails(true);
    setCreatePassword(false);
  };

  const handleChange = (e) => {
    if (typeof (e) !== 'string') {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    } else {
      setFormData({ ...formData, phone: e });
    }
  };

  const signUpToContactDetails = (e) => {
    e.preventDefault();
    setSignUp(false);
    setContactDetails(true);
  };

  const contactDetailsToConfirmPassword = (e) => {
    e.preventDefault();
    setSignUp(false);
    setContactDetails(false);
    setCreatePassword(true);
  };

  const confirmPasswordToOtpVerification = (e) => {
    e.preventDefault();
    setSignUp(false);
    if (formData.password !== formData.confirmPassword) {
      toast.error('Password and Confirm Password do not match');
    } else {
      setLoading(true);
      dispatch(signup(formData, toast, setLoading));
      setContactDetails(false);
      setCreatePassword(false);
      setOtpVerification(true);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    if (otpVerification) {
      dispatch(verify(formData, toast, navigate, setLoading));
    } else if (signIn) {
      dispatch(signin(formData, toast, navigate, setLoading));
    }
  };

  return (
    <div className="auth">
      <form onSubmit={signUpToContactDetails}>
        {signUp && <SignUpCard loading={loading} formData={formData} setSignUp={setSignUp} setSignIn={setSignIn} handleChange={handleChange} />}
      </form>
      <form onSubmit={handleSubmit}>
        {signIn && <SignInCard loading={loading} setSignIn={setSignIn} setSignUp={setSignUp} handleChange={handleChange} />}
      </form>
      <form onSubmit={contactDetailsToConfirmPassword}>
        {contactDetails && (
          <div className="auth__content">
            <div className="auth__goback" onClick={goBackToSignUp}>
              <ArrowBackIcon />
              <h5>Go Back</h5>
            </div>
            <ContactDetailsCard formData={formData} handleChange={handleChange} />
          </div>
        )}
      </form>
      <form onSubmit={handleSubmit}>
        {otpVerification && (
          <div className="auth__content">
            <div className="auth__goback" onClick={goBackToContactDetails}>
              <ArrowBackIcon />
              <h5>Go Back</h5>
            </div>
            <OtpVerificationCard loading={loading} handleChange={handleChange} />
          </div>
        )}
      </form>
      <form onSubmit={confirmPasswordToOtpVerification}>
        {createPassword && (
          <div className="auth__content">
            <div className="auth__goback" onClick={goBackToContactDetails}>
              <ArrowBackIcon />
              <h5>Go Back</h5>
            </div>
            <CreatePasswordCard formData={formData} handleChange={handleChange} />
          </div>
        )}
      </form>
      <div className="auth__copyright">
        <p>All rights  Reserved</p>
        <p>Copyright @Gosafejourney</p>
      </div>
      <Toaster />
    </div>
  );
}

export default Auth;
