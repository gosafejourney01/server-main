import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getProperties } from '../../actions/property';
import DashboardSection from '../../components/HomePage/DashboardSection/DashboardSection';
import FinanceSection from '../../components/HomePage/FinanceSection/FinanceSection';
// import ApprovalsSection from '../../components/HomePage/ApprovalsSection/ApprovalsSection';
import SectionsNavbar from '../../components/HomePage/SectionsNavbar/SectionsNavbar';
import PropertyApprovalSection from '../../components/HomePage/PropertyApprovalSection/PropertyApprovalSection';
import './Home.scss';

function Home() {
  const [isDashboard, setIsDashboard] = useState(true);
  const [isApprovals, setIsApprovals] = useState(false);
  const [isFinance, setIsFinance] = useState(false);

  const allProperties = useSelector((state) => state.property.propertyData);

  const dispatch = useDispatch();

  // Fetching all the data from the database
  useEffect(() => {
    dispatch(getProperties());
  }, []);

  return (
    <div className="home">
      <SectionsNavbar
        isDashboard={isDashboard}
        setIsDashboard={setIsDashboard}
        isApprovals={isApprovals}
        setIsApprovals={setIsApprovals}
        isFinance={isFinance}
        setIsFinance={setIsFinance}
      />
      {isDashboard && <DashboardSection allProperties={allProperties} />}
      {isApprovals && <PropertyApprovalSection properties={allProperties?.data} />}
      {isFinance && <FinanceSection />}
    </div>
  );
}

export default Home;
