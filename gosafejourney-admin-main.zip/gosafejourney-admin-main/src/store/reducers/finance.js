import { FETCH_FINANCE } from '../../constants/actionTypes';

const financeReducer = (state = { financeData: null }, action) => {
  switch (action.type) {
    case FETCH_FINANCE:
      return { ...state, financeData: action?.payload.data };

    default:
      return state;
  }
};

export default financeReducer;
