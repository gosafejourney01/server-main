import { combineReducers } from 'redux';

import auth from './auth';
import property from './property';
import finance from './finance';

export default combineReducers({ auth, property, finance });
