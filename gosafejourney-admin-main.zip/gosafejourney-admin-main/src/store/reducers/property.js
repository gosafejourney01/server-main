import { UPDATE_PROPERTY, FETCH_PROPERTY } from '../../constants/actionTypes';

const propertyReducer = (state = { propertyData: null }, action) => {
  const { type, payload } = action;
  switch (type) {
    case UPDATE_PROPERTY: {
      const updatedProperty = payload;
      const updatedData = state.propertyData.data.map((property) => {
        if (property.id === updatedProperty.id) {
          return updatedProperty; // Replace the matching property with the updated property
        }
        return property; // Keep other properties unchanged
      });

      return { ...state, propertyData: { ...state.propertyData, data: updatedData } };
    }
    case FETCH_PROPERTY: {
      return { ...state, propertyData: payload };
    }
    default:
      return state;
  }
};

export default propertyReducer;
