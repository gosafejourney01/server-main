import { AUTH } from '../constants/actionTypes';
import * as api from '../api';

export const signin = (formData, toast, navigate, setLoading) => async (dispatch) => {
  try {
    const { data } = await api.signIn(formData);
    dispatch({ type: AUTH, data });
    navigate('/');
  } catch (error) {
    console.log(error);
    toast.error('Invalid Credentials');
  }
  setLoading(false);
};

export const signup = (formData, toast, setLoading) => async (dispatch) => {
  try {
    const { data } = await api.signUp(formData);
    dispatch({ type: AUTH, data });
  } catch (error) {
    console.log(error);
    toast.error('Email already exists.');
  }
  setLoading(false);
};

export const verify = (formData, toast, navigate, setLoading) => async (dispatch) => {
  try {
    const { data } = await api.verify(formData);
    dispatch({ type: AUTH, data });
    navigate('/');
  } catch (error) {
    console.log(error);
    toast.error('Invalid/Expired One Time Password');
  }
  setLoading(false);
};
