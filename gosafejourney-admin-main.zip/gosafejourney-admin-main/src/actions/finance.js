import * as api from '../api';
import {
  START_LOADING, END_LOADING, FETCH_FINANCE,
} from '../constants/actionTypes';

const getFinance = (financeQuery) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.fetchFinance(financeQuery);
    console.log(data);
    dispatch({ type: FETCH_FINANCE, payload: data });
    dispatch({ type: END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export default getFinance;
