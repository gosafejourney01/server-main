import * as api from '../api';
import {
  START_LOADING, END_LOADING, FETCH_PROPERTY, CREATE_PROPERTY, UPDATE_PROPERTY,
} from '../constants/actionTypes';

export const getProperty = (id) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.fetchProperty(id);
    dispatch({ type: FETCH_PROPERTY, payload: data });
    dispatch({ type: END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const createProperty = (property) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.createProperty(property);
    console.log(data);
    dispatch({ type: CREATE_PROPERTY, payload: data });
    dispatch({ type: END_LOADING });
    return data;
  } catch (error) {
    console.log(error);
    return error;
  }
};

export const updateProperty = (id, property) => async (dispatch) => {
  try {
    const { data } = await api.updateProperty(id, property);
    dispatch({ type: UPDATE_PROPERTY, payload: data });
  } catch (error) {
    console.log(error);
  }
};

export const getProperties = () => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.getProperties();
    dispatch({ type: FETCH_PROPERTY, payload: data });
    dispatch({ type: END_LOADING });
  } catch (error) {
    console.log(error);
  }
};
