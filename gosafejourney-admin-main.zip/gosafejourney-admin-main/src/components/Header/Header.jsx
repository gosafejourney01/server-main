import React, { useEffect, useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import decode from 'jwt-decode';
import {
  Avatar, IconButton, ListItemIcon, Menu, MenuItem,
} from '@mui/material';
import { Logout, Settings, HelpOutlineRounded } from '@mui/icons-material';
import { LOGOUT } from '../../constants/actionTypes';
import logo from '../../images/logo.svg';
import './Header.scss';

function Header() {
  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('profile')));
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const logout = () => {
    dispatch({ type: LOGOUT });
    navigate('/auth');
    setUser(null);
  };

  useEffect(() => {
    const token = user?.token;
    if (token) {
      const decodedToken = decode(token);

      if (decodedToken.exp * 1000 < new Date().getTime()) logout();
    }
    setUser(JSON.parse(localStorage.getItem('profile')));
  }, [location]);

  return (
    <div className="header">
      <div className="header__content">
        <div className="header__logo">
          <NavLink to="/"><img src={logo} alt="gosafejourney logo" /></NavLink>
        </div>
        {!user && (
          <div className="header__property">
            <IconButton>
              <HelpOutlineRounded />
            </IconButton>
            <p>Help</p>
          </div>
        )}
        {user && (
          <div className="header__profile">
            <div className="header__property">
              <IconButton
                onClick={handleClick}
                size="small"
                sx={{ ml: 2 }}
                aria-controls={open ? 'account-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={open ? 'true' : undefined}
              >
                <Avatar className="header__profile" alt={user.result.fullName} />
              </IconButton>
              <p>Account</p>
            </div>
          </div>
        )}
      </div>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 26,
              height: 26,
              mr: 1,
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        {user && (
          <MenuItem onClick={() => navigate('/')}>
            <Avatar />
            {' '}
            My Dashboard
          </MenuItem>
        )}
        {user && (
          <MenuItem onClick={() => navigate('/reset-password')}>
            <ListItemIcon>
              <Settings fontSize="medium" />
            </ListItemIcon>
            Change Password
          </MenuItem>
        )}
        <MenuItem onClick={logout}>
          <ListItemIcon>
            <Logout fontSize="medium" />
          </ListItemIcon>
          Logout
        </MenuItem>
      </Menu>
    </div>
  );
}

export default Header;
