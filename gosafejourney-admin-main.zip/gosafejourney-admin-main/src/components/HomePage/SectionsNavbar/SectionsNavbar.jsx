import React from 'react';
import './SectionsNavbar.scss';

function SectionsNavbar({
  isDashboard,
  setIsDashboard,
  isApprovals,
  setIsApprovals,
  isFinance,
  setIsFinance,
}) {
  const openDashBoard = () => {
    setIsDashboard(true);
    setIsApprovals(false);
    setIsFinance(false);
  };

  const openApprovals = () => {
    setIsDashboard(false);
    setIsApprovals(true);
    setIsFinance(false);
  };

  const openFinance = () => {
    setIsDashboard(false);
    setIsApprovals(false);
    setIsFinance(true);
  };

  return (
    <div className="sectionsNavbar">
      <div className="sectionsNavbar__head">
        <div className="sectionsNavbar__headcontent">
          <div onClick={openDashBoard} className={isDashboard ? 'sectionsNavbar__onclick' : 'sectionsNavbar__section'}>
            <h4>Dashboard</h4>
          </div>
          <div onClick={openApprovals} className={isApprovals ? 'sectionsNavbar__onclick' : 'sectionsNavbar__section'}>
            <h4>Approvals</h4>
          </div>
          <div onClick={openFinance} className={isFinance ? 'sectionsNavbar__onclick' : 'sectionsNavbar__section'}>
            <h4>Finance</h4>
          </div>
        </div>
      </div>
      <div className="sectionsNavbar__divider" />
    </div>
  );
}

export default SectionsNavbar;
