import React, { useEffect, useState } from 'react';
import { Button, TextField } from '@mui/material';
import { toast, Toaster } from 'react-hot-toast';
import { styled } from '@mui/material/styles';
import PropertyStatsTable from './PropertyStatsTable/PropertyStatsTable';
/* import OngoingUpcomingReservationsTable from './OngoingUpcomingReservationsTable/OngoingUpcomingReservationsTable';
import PropertyBookingsToggle from './PropertyBookingsToggle/PropertyBookingsToggle'; */
import './DashboardSection.scss';
import { getDetails, updateDetails } from '../../../api';

const FormContainer = styled('form')({
  display: 'flex',
  flexDirection: 'row',
  gap: '16px',
  maxWidth: '300px',
  margin: '0 auto',
});

function DashboardSection({ allProperties }) {
  const [comission, setComission] = useState(0);
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await updateDetails({ comission, key: 'secretkey' });
      setComission(response.data.comission);
      toast.success('Comission updated');
    } catch (error) {
      toast.error('Something went wrong');
    }
  };

  useEffect(() => {
    const getAdminDetails = async () => {
      const response = await getDetails();
      console.log(response?.data[0]);
      setComission(response?.data[0]?.comission);
    };
    getAdminDetails();
  }, []);

  return (
    <div>
      <div>
        <h2>Activity</h2>
        <h4>Click on the property name to view room details.</h4>
        <PropertyStatsTable allProperties={allProperties} />
        {/* <h2>Upcoming 48 hours reservations and details</h2>
        <OngoingUpcomingReservationsTable />
        <h2>Property</h2>
        <PropertyBookingsToggle /> */}
      </div>
      <div style={{ marginTop: '30px' }}>
        <FormContainer onSubmit={handleSubmit}>
          <TextField label="Comission Percentage" variant="outlined" value={comission} onChange={(e) => setComission(e.target.value)} />
          <Button type="submit" variant="contained" color="primary">
            Update
          </Button>
        </FormContainer>
      </div>
      <Toaster />
    </div>
  );
}

export default DashboardSection;
