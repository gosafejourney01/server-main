/* eslint-disable */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import Paper from '@mui/material/Paper';
import { visuallyHidden } from '@mui/utils';
import { styled } from '@mui/material/styles';
import { AppBar, Avatar, Button, Dialog, Divider, IconButton, List, ListItem, ListItemText, MobileStepper, Modal, Slide, Toolbar, Typography } from '@mui/material';
import './PropertyStatsTable.scss';
import Tooltip, { TooltipPrimitive } from '@atlaskit/tooltip';
import moment from 'moment';
import { getRoom } from '../../../../api';
import CloseIcon from '@mui/icons-material/Close';
import { CloseRounded } from '@mui/icons-material';
import { useTheme } from "@material-ui/core/styles";
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}


function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
  const stabilizedThis = array?.map((el, index) => [el, index]);
  stabilizedThis?.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis?.map((el) => el[0]);
}

const headCells = [
  {
    id: 'propertyName',
    numeric: false,
    disablePadding: false,
    label: 'Property Name',
  },
  {
    id: 'propertyContactName',
    numeric: false,
    disablePadding: false,
    label: 'Property Contact Name',
  },
  {
    id: 'noBookedRooms',
    numeric: true,
    disablePadding: false,
    label: 'Current Number of Bookings',
  },
  {
    id: 'isOpenForBookings',
    numeric: false,
    disablePadding: false,
    label: 'Booking Status',
  },
  {
    id: 'createdAt',
    numeric: false,
    disablePadding: false,
    label: 'Joined Us On',
  },
  {
    id: 'propertyLocation',
    numeric: false,
    disablePadding: false,
    label: 'Property Location',
  },
  {
    id: 'income',
    numeric: true,
    disablePadding: false,
    label: 'Total Income',
  },
];

function EnhancedTableHead(props) {
  const {
    order, orderBy, onRequestSort,
  } = props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align="left"
            padding={headCell.disablePadding ? 'none' : 'normal'}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : 'asc'}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  onRequestSort: PropTypes.func.isRequired,
  order: PropTypes.oneOf(['asc', 'desc']).isRequired,
  orderBy: PropTypes.string.isRequired,
};

function PropertyStatsTable({ allProperties }) {
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('noRooms');
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [rows, setRows] = React.useState([]);
  const [open, setOpen] = useState(false);
  const [currentModalData, setCurrentModalData] = useState({});
  const [currentModalDataRooms, setCurrentModalDataRooms] = useState([]);

  const handleOpen = async (row) => {
    setOpen(true);
    setCurrentModalData(row);
    const rooms = await getRoom({
      roomId: row.rooms,
      propertyId: row._id,
    });
    console.log('rooms', rooms);
    setCurrentModalDataRooms(rooms?.data);
  };

  console.log('currentModalDataRooms', currentModalDataRooms);

  const handleClose = () => {
    setOpen(false);
    setCurrentModalData({});
    setCurrentModalDataRooms([]);
  };

  const InlineDialog = styled(TooltipPrimitive)`
    background: white;
    border-radius: 4px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    box-sizing: content-box; /* do not set this to border-box or it will break the overflow handling */
    color: #333;
    max-height: 400px;
    max-width: 300px;
    padding: 15px;
  `;

  useEffect(() => {
    setRows(allProperties?.data);
  }, [allProperties]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  if (!rows) {
    // return only heading
    return (
      <Box className="propertyStatsTable" sx={{ width: '100%' }}>
        <Paper sx={{ width: '100%', mb: 2 }}>
          <TableContainer>
            <Table
              sx={{ minWidth: 750 }}
              aria-labelledby="tableTitle"
              size="medium"
            >
              <EnhancedTableHead
                order={order}
                orderBy={orderBy}
                onRequestSort={handleRequestSort}
              />
            </Table>
          </TableContainer>
        </Paper>
      </Box>
    );
  }

  if (rows.length === 0) {
    return <div>No Properties Found</div>;
  }

  return (
    <div>
      <Box className="propertyStatsTable" sx={{ width: '100%' }}>
        <Paper sx={{ width: '100%', mb: 2 }}>
          <TableContainer>
            <Table
              sx={{ minWidth: 750 }}
              aria-labelledby="tableTitle"
              size="medium"
            >
              <EnhancedTableHead
                order={order}
                orderBy={orderBy}
                onRequestSort={handleRequestSort}
              />
              <TableBody>
                {stableSort(rows, getComparator(order, orderBy))
                  ?.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((row, index) => (
                    <TableRow
                      hover
                      tabIndex={-1}
                      key={index}
                    >
                      <TableCell className="propertyStatsTable__roomType" style={{ cursor: 'pointer' }} onClick={() => handleOpen(row)}>{row.propertyName}</TableCell>
                      <TableCell className="propertyStatsTable__rooms">
                        {row.propertyContactName}
                      </TableCell>
                      <TableCell className="propertyStatsTable__bookedRooms">
                        {row.propertyBookings.length}
                        {' '}
                        {row.propertyBookings.length === 1 || row.propertyBookings.length === 0 ? 'Room' : 'Rooms'}
                      </TableCell>
                      <TableCell className="propertyStatsTable__emptyRooms">
                        {row.isApproved ? 'Open' : 'Closed'}
                      </TableCell>
                      <TableCell className="ongoingUpcomingReservationsTable__checkOut">
                        {moment(row.createdAt).format('DD MMM, YYYY')}
                      </TableCell>
                      <TableCell className="ongoingUpcomingReservationsTable__checkOut">
                        {row.city}
                      </TableCell>
                      <TableCell className="ongoingUpcomingReservationsTable__checkOut">
                        <Tooltip
                          position="bottom"
                          component={InlineDialog}
                          content={
                            (
                              <table>
                                <tr>
                                  <th>Month</th>
                                  <th>Income</th>
                                </tr>
                                <tr>
                                  <td>January</td>
                                  <td>{row.income[1]}</td>
                                </tr>
                                <tr>
                                  <td>February</td>
                                  <td>{row.income[2]}</td>
                                </tr>
                                <tr>
                                  <td>March</td>
                                  <td>{row.income[3]}</td>
                                </tr>
                                <tr>
                                  <td>April</td>
                                  <td>{row.income[4]}</td>
                                </tr>
                                <tr>
                                  <td>May</td>
                                  <td>{row.income[5]}</td>
                                </tr>
                                <tr>
                                  <td>June</td>
                                  <td>{row.income[6]}</td>
                                </tr>
                                <tr>
                                  <td>July</td>
                                  <td>{row.income[7]}</td>
                                </tr>
                                <tr>
                                  <td>August</td>
                                  <td>{row.income[8]}</td>
                                </tr>
                                <tr>
                                  <td>September</td>
                                  <td>{row.income[9]}</td>
                                </tr>
                                <tr>
                                  <td>October</td>
                                  <td>{row.income[10]}</td>
                                </tr>
                                <tr>
                                  <td>November</td>
                                  <td>{row.income[11]}</td>
                                </tr>
                                <tr>
                                  <td>December</td>
                                  <td>{row.income[12]}</td>
                                </tr>
                              </table>)}
                        >
                          {(tooltipProps) => (
                            <span {...tooltipProps}>
                              {row.totalIncome}
                            </span>
                          )}
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                {emptyRows > 0 && (
                  <TableRow
                    style={{
                      height: (53) * emptyRows,
                    }}
                  >
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={rows?.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </Box>
      <Dialog
        fullScreen
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <AppBar sx={{ position: 'relative' }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseRounded />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              {currentModalData.propertyName}
            </Typography>
          </Toolbar>
        </AppBar>
        <List>
          {
            <>
              {currentModalDataRooms.length === 0 ? (
                <div style={{ margin: '15px', marginLeft: '0px', textAlign: 'center', fontStyle: 'italic' }}>
                  No Rooms Available
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  {currentModalDataRooms.map((rooms, index) => (
                    <div key={index} style={{ border: '1px solid #ccc', borderRadius: '8px', padding: '10px', marginBottom: '20px', width: '80%', maxWidth: '600px' }}>
                      <h3 style={{ marginBottom: '5px' }}>{rooms.roomName}</h3>
                      <p>Property Name: {rooms.propertyId.propertyName}</p>
                      <p>Property Type: {rooms.propertyId.propertyType}</p>
                      <p>Property Rating: {rooms.propertyId.rating}</p>
                      <p>Property Phone: {rooms.propertyId.phone}</p>
                      <p>Property Image: </p>
                      <div style={{ maxWidth: '100%', maxHeight: '200px', overflow: 'hidden', borderRadius: '4px' }}>
                        <Carousel>
                          {rooms.propertyId.propertyImages.map((image, index) => (
                            <div key={index} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                              <img
                                src={image}
                                alt={`Image ${index + 1}`}
                                style={{ maxWidth: '300px', maxHeight: '200px', objectFit: 'cover' }}
                              />
                            </div>
                          ))}
                        </Carousel>
                      </div>
                      <p>Property Aadhar: {rooms.propertyId.aadhar}</p>
                      <p>Property Gst No: {rooms.propertyId.gstin}</p>
                      <p>Property Pan No: {rooms.propertyId.pan}</p>
                      <p>Property IFSC Code: {rooms.propertyId.ifscCode}</p>
                      <p>Property Account No: {rooms.propertyId.accountNumber}</p>
                      <p>Property Account Holder Name: {rooms.propertyId.accountHolderName}</p>
                      <p>Property Reviews: </p>
                      <div>
                        {
                          rooms.propertyId?.reviews?.map((review) => {
                            return (
                              <>
                                <p>Feedback By User: {review.feedback}</p>
                                <p>Rating by User: {review.rating}</p>
                                <p>Reviewd On : {review.reviewDate}</p>
                              </>
                            )
                          })}</div>
                      <p>Room Type: {rooms.roomType}</p>
                      <p>Room Price: ${rooms.price}</p>
                      <p>Number of Rooms: {rooms.noRooms}</p>
                      <p>Images of Rooms:</p>
                      <div style={{ maxWidth: '100%', maxHeight: '200px', overflow: 'hidden', borderRadius: '4px' }}>
                        <Carousel>
                          {rooms.images.map((image, index) => (
                            <div key={index} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                              <img
                                src={image}
                                alt={`Image ${index + 1}`}
                                style={{ maxWidth: '300px', maxHeight: '200px', objectFit: 'cover' }}
                              />
                            </div>
                          ))}
                        </Carousel>
                      </div>
                      <p>Property Documents:</p>
                      <embed src={rooms?.propertyId?.file}></embed>
                      <p>Property Cancellation: {`before ${rooms.propertyId.cancellationDays} days(s)`}</p>
                      <p>Property Parking: {rooms.propertyId.isParkingProvided==='free'? 'Free Parking Provided' : 'Parking will be charged'}</p>
                      <p>Property Cancellation: {rooms.propertyId.isSmokingAlllowed===false ? 'Smoking is not allowed' : 'Smoking Is Allowed'}</p>
                      <p>Property Check In Time: {rooms.propertyId.checkInTime.substring(11,19) }</p>
                      <p>Property Check Out TIme: {rooms.propertyId.checkOutTime.substring(11,19)}</p>
                      <p>Property Commision: {rooms.propertyId.commission}</p>
                      <p>Property Commission Name: {rooms.propertyId.commissionName}</p>
                    </div>
                  ))}
                </div>
              )}
            </>
          }
        </List>
      </Dialog>
    </div>
  );
}

export default PropertyStatsTable;
