import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import Switch from '@mui/material/Switch';
import './PropertyBookingsToggle.scss';

function PropertyBookingsToggle() {
  const [isPropertyVisible, setIsPropertyVisible] = useState(false);
  const IOSSwitch = styled((props) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
  ))(({ theme }) => ({
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
      padding: 0,
      margin: 2,
      transitionDuration: '300ms',
      '&.Mui-checked': {
        transform: 'translateX(32px)',
        color: '#fff',
        '& + .MuiSwitch-track': {
          backgroundColor: theme.palette.mode === 'dark' ? '#2ECA45' : '#043263',
          opacity: 1,
          border: 0,
        },
        '&.Mui-disabled + .MuiSwitch-track': {
          opacity: 0.5,
        },
      },
      '&.Mui-focusVisible .MuiSwitch-thumb': {
        color: '#33cf4d',
        border: '6px solid #fff',
      },
      '&.Mui-disabled .MuiSwitch-thumb': {
        color:
          theme.palette.mode === 'light'
            ? theme.palette.grey[100]
            : theme.palette.grey[600],
      },
      '&.Mui-disabled + .MuiSwitch-track': {
        opacity: theme.palette.mode === 'light' ? 0.7 : 0.3,
      },
    },
    '& .MuiSwitch-thumb': {
      boxSizing: 'border-box',
      width: 22,
      height: 22,
    },
    '& .MuiSwitch-track': {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === 'light' ? '#E9E9EA' : '#39393D',
      opacity: 1,
      transition: theme.transitions.create(['background-color'], {
        duration: 500,
      }),
    },
  }));

  const handleCheckedChange = (e) => {
    setIsPropertyVisible(e.target.checked);
  };

  return (
    <div className="propertyBookingsToggle">
      <div className="propertyBookingsToggle__name">
        <h4>Brc</h4>
        <h4>Hyderabad,Telengana</h4>
      </div>
      <div className="propertyBookingsToggle__toggle">
        <h4>Close Bookings</h4>
        <IOSSwitch sx={{ m: 1 }} name="isSmokingAllowed" checked={isPropertyVisible} onChange={handleCheckedChange} />
        <h4>Active</h4>
      </div>
    </div>
  );
}

export default PropertyBookingsToggle;
