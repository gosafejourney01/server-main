/* eslint-disable no-underscore-dangle */
import React from 'react';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import TextField from '@mui/material/TextField';
import './InvoiceCheckOut.scss';

function InvoiceCheckOut({ reservationCheckOutPeriod, setReservationCheckOutPeriod }) {
  const handleDateChange = (date) => {
    setReservationCheckOutPeriod(date);
  };

  return (
    <div className="invoiceCheckOut">
      <h4>Invoices for reservation check-out period:</h4>
      <LocalizationProvider dateAdapter={AdapterMoment}>
        <DatePicker
          openTo="year"
          views={['year', 'month']}
          value={reservationCheckOutPeriod}
          maxDate={new Date()}
          onChange={(value) => handleDateChange(value._d)}
          renderInput={(params) => <TextField {...params} />}
          className="invoiceCheckOut__date"
        />
      </LocalizationProvider>
      <p>Invoices are calculated based on the reservation check-out date. The statement doesn’t include payments you’ll receive from gosafejourney  by the month end.</p>
    </div>
  );
}

export default InvoiceCheckOut;
