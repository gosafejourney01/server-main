/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import Paper from '@mui/material/Paper';
import { visuallyHidden } from '@mui/utils';
import './FinanceTable.scss';
import moment from 'moment/moment';
import Tooltip, { TooltipPrimitive } from '@atlaskit/tooltip';
import { styled } from '@mui/material/styles';
import getFinance from '../../../../actions/finance';

const InlineDialog = styled(TooltipPrimitive)`
background: white;
border-radius: 4px;
box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
box-sizing: content-box; /* do not set this to border-box or it will break the overflow handling */
color: #333;
max-height: 300px;
max-width: 300px;
padding: 15px;
`;

function createData(invoice, bookingId, propertyName, invoiceDate, amount, dueDate, status, clientDetails, guestData) {
  return {
    invoice,
    bookingId,
    propertyName,
    invoiceDate,
    amount,
    dueDate,
    status,
    clientDetails,
    guestData,

  };
}

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

const headCells = [
  {
    id: 'invoice',
    numeric: false,
    disablePadding: false,
    label: 'Invoice',
  },
  {
    id: 'bookingId',
    numeric: false,
    disablePadding: false,
    label: 'ID',
  },
  {
    id: ' propertyName',
    numeric: false,
    disablePadding: false,
    label: 'Property Name',
  },
  {
    id: 'invoiceDate',
    numeric: false,
    disablePadding: false,
    label: 'Invoice Date',
  },
  {
    id: 'amount',
    numeric: false,
    disablePadding: false,
    label: 'Amount',
  },
  {
    id: 'dueDate',
    numeric: false,
    disablePadding: false,
    label: 'Date Due',
  },
  {
    id: 'status',
    numeric: false,
    disablePadding: false,
    label: 'Status',
  },
];

function EnhancedTableHead(props) {
  const {
    order, orderBy, onRequestSort,
  } = props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? 'right' : 'left'}
            padding={headCell.disablePadding ? 'none' : 'normal'}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : 'asc'}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  onRequestSort: PropTypes.func.isRequired,
  order: PropTypes.oneOf(['asc', 'desc']).isRequired,
  orderBy: PropTypes.string.isRequired,
};

function FinanceTable({ reservationCheckOutPeriod }) {
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('invoiceDate');
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [rows, setRows] = React.useState([]);

  const handleClick = (invoicePath) => {
    window.open(`${process.env.REACT_APP_SERVER_URL}${invoicePath}`);
  };

  const allFinances = useSelector((state) => state.finance.financeData);

  React.useEffect(() => {
    if (allFinances) {
      const newRows = [];
      allFinances.forEach((finance) => {
        // eslint-disable-next-line no-underscore-dangle
        newRows.push(createData(finance.invoice, finance._id, finance.propertyName, finance.createdAt, finance.amount, finance.checkInDate, finance.bookingStatus, finance.clientDetails, finance.guestData));
      });
      setRows(newRows);
    }
  }, [allFinances]);

  const dispatch = useDispatch();

  // Fetching all the data from the database
  React.useEffect(() => {
    dispatch(getFinance({ dateString: reservationCheckOutPeriod, page, rows: rowsPerPage }));
  }, [reservationCheckOutPeriod, page, rowsPerPage]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  return (
    <Box className="financeTable" sx={{ width: '100%' }}>
      <Paper sx={{ width: '100%', mb: 2 }}>
        <TableContainer>
          <Table
            sx={{ minWidth: 750 }}
            aria-labelledby="tableTitle"
            size="medium"
          >
            <EnhancedTableHead
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
            />
            <TableBody>
              {rows && stableSort(rows, getComparator(order, orderBy))
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => (
                  <TableRow
                    hover
                    tabIndex={-1}
                    key={index}
                  >
                    <TableCell className="financeTable__invoice">
                      {/* {row.invoice} */}
                      {' '}
                      <div onClick={() => handleClick(row.invoice)}>
                        <h6>Download</h6>
                      </div>
                    </TableCell>
                    <TableCell className="financeTable__bookingId">{row.bookingId}</TableCell>
                    <TableCell className="financeTable__propertyName">
                      {row.propertyName}
                    </TableCell>
                    <TableCell>
                      {moment(row.invoiceDate).format('MMM DD, YYYY')}
                    </TableCell>
                    <TableCell className="financeTable__amount">
                      {row.amount}
                      {' '}
                      <h6>
                        <Tooltip
                          position="right"
                          component={InlineDialog}
                          content={`Name : ${row.clientDetails.fullName} || Phone : ${row.clientDetails.phone} || Email : ${row.clientDetails.email}`}
                        >
                          {(tooltipProps) => (
                            <span {...tooltipProps}>
                              View Reservation
                            </span>
                          )}
                        </Tooltip>
                      </h6>
                    </TableCell>

                    <TableCell>
                      {moment(row.dueDate).format('DD MMM, YYYY')}
                    </TableCell>
                    <TableCell className={row.status === 'Pending' ? 'financeTable__bookingCancelled' : 'financeTable__bookingActive'}>
                      {row.status}
                    </TableCell>
                  </TableRow>
                ))}
              {emptyRows > 0 && (
                <TableRow
                  style={{
                    height: (53) * emptyRows,
                  }}
                >
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
    </Box>
  );
}

export default FinanceTable;
