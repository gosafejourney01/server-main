/* eslint-disable no-unused-vars */
/* eslint-disable no-underscore-dangle */
import React, { useState } from 'react';
import FinanceTable from './FinanceTable/FinanceTable';
import InvoiceCheckOut from './InvoiceCheckOut/InvoiceCheckOut';

function FinanceSection() {
  const [reservationCheckOutPeriod, setReservationCheckOutPeriod] = useState(new Date());
  return (
    <div>
      <h2>Finance</h2>
      <InvoiceCheckOut reservationCheckOutPeriod={reservationCheckOutPeriod} setReservationCheckOutPeriod={setReservationCheckOutPeriod} />
      <FinanceTable reservationCheckOutPeriod={reservationCheckOutPeriod} />
    </div>
  );
}

export default FinanceSection;
