import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { toast, Toaster } from 'react-hot-toast';
import { styled } from '@mui/material/styles';
import Switch from '@mui/material/Switch';
import Tooltip, { TooltipPrimitive } from '@atlaskit/tooltip';
import { CloseRounded } from '@mui/icons-material';
import {
  AppBar,
  Dialog,
  IconButton,
  List,
  // Slide,
  Toolbar,
  Typography,
} from '@mui/material';
import { Carousel } from 'react-responsive-carousel';
import { updateProperty } from '../../../actions/property';
import './PropertyBookingsTogle.scss';

function PropertyApprovalSection({ properties }) {
  const IOSSwitch = styled((props) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
  ))(({ theme }) => ({
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
      padding: 0,
      margin: 2,
      transitionDuration: '300ms',
      '&.Mui-checked': {
        transform: 'translateX(32px)',
        color: '#fff',
        '& + .MuiSwitch-track': {
          backgroundColor: theme.palette.mode === 'dark' ? '#2ECA45' : '#043263',
          opacity: 1,
          border: 0,
        },
        '&.Mui-disabled + .MuiSwitch-track': {
          opacity: 0.5,
        },
      },
      '&.Mui-focusVisible .MuiSwitch-thumb': {
        color: '#33cf4d',
        border: '6px solid #fff',
      },
      '&.Mui-disabled .MuiSwitch-thumb': {
        color:
          theme.palette.mode === 'light'
            ? theme.palette.grey[100]
            : theme.palette.grey[600],
      },
      '&.Mui-disabled + .MuiSwitch-track': {
        opacity: theme.palette.mode === 'light' ? 0.7 : 0.3,
      },
    },
    '& .MuiSwitch-thumb': {
      boxSizing: 'border-box',
      width: 22,
      height: 22,
    },
    '& .MuiSwitch-track': {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === 'light' ? '#E9E9EA' : '#39393D',
      opacity: 1,
      transition: theme.transitions.create(['background-color'], {
        duration: 500,
      }),
    },
  }));

  const dispatch = useDispatch();

  const handleCheckedChange = async (e, id, property) => {
    dispatch(updateProperty(id, { isApproved: !property.isApproved }));
    if (!property.isApproved) {
      toast.success(`${property.propertyName} allowed for bookings.`);
    } else {
      toast.error(`${property.propertyName} will not accept bookings.`);
    }
  };

  const [open, setOpen] = useState(false);
  const [propertyData, setPropertyData] = useState([]);

  const handleTooltipClicked = (property) => {
    console.log('property', property);
    setOpen(true);
    setPropertyData(property);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const InlineDialog = styled(TooltipPrimitive)`
    background: white;
    border-radius: 4px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    box-sizing: content-box; /* do not set this to border-box or it will break the overflow handling */
    color: #333;
    max-height: 300px;
    max-width: 300px;
    padding: 15px;
  `;

  if (!properties) return (<div style={{ margin: '30px' }}>Loading...</div>);

  if (properties.length === 0) return (<div style={{ margin: '30px' }}>No properties found.</div>);

  return (
    <div>
      <h2>Property Approval</h2>
      {properties.map((property) => {
        const { _id } = property;

        return (
          <div className="propertyBookingsToggle" key={_id}>
            <div className="propertyBookingsToggle__name">
              <h4 style={{ cursor: 'pointer' }}>
                <Tooltip
                  position="right"
                  component={InlineDialog}
                  content={`Property: ${property.propertyName} | Owner Name: ${property.propertyContactName} | Contact Number: ${property.phone} | Location: ${property.city} - ${property.pincode} | Booking Status: ${property.isApproved === true ? 'Open' : 'Close'} | Aadhar: ${property.aadhar} | PAN: ${property.pan}`}
                >
                  {(tooltipProps) => (
                    <span {...tooltipProps} onClick={() => handleTooltipClicked(property)}>
                      {property.propertyName}
                    </span>
                  )}
                </Tooltip>
              </h4>
              <h4>
                {property.city}
              </h4>
            </div>
            <div className="propertyBookingsToggle__toggle">
              <h4>Disallow</h4>
              <IOSSwitch sx={{ m: 1 }} name="isOpenForBooking" checked={property.isApproved} onChange={(e) => handleCheckedChange(e, _id, property)} />
              <h4>Allow</h4>
            </div>
          </div>
        );
      })}
      <Toaster />
      <Dialog
        fullScreen
        open={open}
        onClose={handleClose}
      // TransitionComponent={Transition}
      >
        <AppBar sx={{ position: 'relative' }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseRounded />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              Property Descriptions
            </Typography>
          </Toolbar>
        </AppBar>
        <List>
          {
            propertyData.length === 0 ? (
              <div style={
                {
                  margin: '15px', marginLeft: '0px', textAlign: 'center', fontStyle: 'italic',
                }
              }
              >
                No Property Data Available
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div style={
                  {
                    border: '1px solid #ccc', borderRadius: '8px', padding: '10px', marginBottom: '20px', width: '80%', maxWidth: '600px',
                  }
                }
                >
                  {/* <h3 style={{ marginBottom: '5px' }}>{rooms.roomName}</h3> */}
                  <p>
                    Name:
                    {propertyData.propertyName}
                  </p>
                  <p>
                    Type:
                    {propertyData.propertyType}
                  </p>
                  <p>
                    Address:
                    {propertyData.address}
                  </p>
                  <p>
                    Rating:
                    {propertyData.rating}
                  </p>
                  <p>
                    Phone:
                    {propertyData.phone}
                  </p>
                  <p>
                    Image:
                  </p>
                  <div style={
                    {
                      maxWidth: '100%', maxHeight: '200px', overflow: 'hidden', borderRadius: '4px',
                    }
                  }
                  >
                    <Carousel>
                      {
                        propertyData.propertyImages.map((image, index) => (
                          <div
                            key={index}
                            style={
                              {
                                display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%',
                              }
                            }
                          >
                            <img
                              src={image}
                              alt={`Image ${index + 1}`}
                              style={{ maxWidth: '300px', maxHeight: '200px', objectFit: 'cover' }}
                            />
                          </div>
                        ))
                      }
                    </Carousel>
                  </div>
                  <p>
                    Aadhar:
                    {propertyData.aadhar}
                  </p>
                  <p>
                    Gst No:
                    {propertyData.gstin}
                  </p>
                  <p>
                    Pan No:
                    {propertyData.pan}
                  </p>
                  <p>
                    IFSC Code:
                    {propertyData.ifscCode}
                  </p>
                  <p>
                    Account No:
                    {propertyData.accountNumber}
                  </p>
                  <p>
                    Account Holder Name:
                    {propertyData.accountHolderName}
                  </p>
                  <p>
                    Reviews:
                    {propertyData?.reviews?.map((review) => (
                      <>
                        <p>
                          Feedback By User:
                          {review.feedback}
                        </p>
                        <p>
                          Rating by User:
                          {review.rating}
                        </p>
                        <p>
                          Reviewd On :
                          {review.reviewDate}
                        </p>
                      </>
                    ))}
                  </p>
                </div>
              </div>
            )
          }
        </List>
      </Dialog>
    </div>
  );
}

export default PropertyApprovalSection;
