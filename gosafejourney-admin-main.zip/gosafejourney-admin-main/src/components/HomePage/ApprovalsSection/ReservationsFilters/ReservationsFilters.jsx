import React from 'react';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TextField } from '@mui/material';
import './ReservationsFilters.scss';

function ReservationsFilters({ filterData, handleChange }) {
  return (
    <LocalizationProvider dateAdapter={AdapterMoment}>
      <div className="reservationsFilters">
        <div className="reservationsFilters__filter">
          <h5>Date of</h5>
          <DatePicker
            label="Check In"
            className="reservationsFilters__input"
            inputFormat="DD/MM/YYYY"
            value={filterData.checkInDate}
            onChange={(value) => handleChange('checkInDate', value)}
            renderInput={(params) => <TextField {...params} />}
          />
        </div>
        <div className="reservationsFilters__filter">
          <h5>Date of</h5>
          <DatePicker
            label="Check Out"
            className="reservationsFilters__input"
            inputFormat="DD/MM/YYYY"
            value={filterData.checkOutDate}
            onChange={(value) => handleChange('checkOutDate', value)}
            renderInput={(params) => <TextField {...params} />}
          />
        </div>
        <div className="reservationsFilters__filter">
          <h5>Filters</h5>
          <select name="reservationType" value={filterData.reservationType} className="reservationsFilters__input reservationsFilters__select" onChange={(e) => handleChange(e.target.name, e.target.value)}>
            <option value="all">All</option>
            <option value="past">Past</option>
            <option value="ongoing">Ongoing</option>
            <option value="upcoming">Upcoming</option>
          </select>
        </div>
      </div>
    </LocalizationProvider>
  );
}

export default ReservationsFilters;
