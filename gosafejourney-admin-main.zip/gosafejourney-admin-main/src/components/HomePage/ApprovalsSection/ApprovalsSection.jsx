import React, { useState } from 'react';
import ReservationsFilters from './ReservationsFilters/ReservationsFilters';
import './ApprovalsSection.scss';
import ApprovalsSection from './ApprovalsTable/ApprovalsTable';

function ReservationsSection() {
  const [filterData, setFilterData] = useState({
    checkInDate: null,
    checkOutDate: null,
    reservationType: 'all',
  });

  const handleChange = (filterName, filterValue) => {
    setFilterData({ ...filterData, [filterName]: filterValue });
  };

  return (
    <div>
      <h2>Reservations</h2>
      <ReservationsFilters
        filterData={filterData}
        handleChange={handleChange}
      />
      <ApprovalsSection filterData={filterData} />
    </div>
  );
}

export default ReservationsSection;
