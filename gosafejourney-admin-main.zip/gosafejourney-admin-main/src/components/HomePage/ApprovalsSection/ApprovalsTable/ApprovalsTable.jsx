import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import Paper from '@mui/material/Paper';
import { visuallyHidden } from '@mui/utils';
import './ApprovalsTable.scss';
import moment from 'moment/moment';

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

const headCells = [
  {
    id: 'bookingId',
    numeric: false,
    disablePadding: false,
    label: 'Booking Id',
  },
  {
    id: 'clientName',
    numeric: false,
    disablePadding: false,
    label: 'Client Name',
  },
  {
    id: 'bookingStatus',
    numeric: false,
    disablePadding: false,
    label: 'Booking Status',
  },
  {
    id: 'checkInDate',
    numeric: false,
    disablePadding: false,
    label: 'Check In Date',
  },
  {
    id: 'checkOutDate',
    numeric: false,
    disablePadding: false,
    label: 'Check Out Date',
  },
  {
    id: 'roomType',
    numeric: false,
    disablePadding: false,
    label: 'Room Type',
  },
];

function EnhancedTableHead(props) {
  const {
    order, orderBy, onRequestSort,
  } = props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? 'right' : 'left'}
            padding={headCell.disablePadding ? 'none' : 'normal'}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : 'asc'}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  onRequestSort: PropTypes.func.isRequired,
  order: PropTypes.oneOf(['asc', 'desc']).isRequired,
  orderBy: PropTypes.string.isRequired,
};

function ReservationsTable({ filterData }) {
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('checkInDate');
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const reservationData = [
    {
      bookingId: '1902903',
      clientName: 'Shrishti Goyal',
      bookingStatus: 'Arriving',
      checkInDate: '2023-01-17T11:01:23Z',
      checkOutDate: '2023-01-18T11:01:23Z',
      roomType: 'Double Bed Room',
    },
    {
      bookingId: '1432903',
      clientName: 'Muthu swamy venu gopala iyer',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-19T11:01:23Z',
      roomType: 'Triple Bed Room',
    },
    {
      bookingId: '1432904',
      clientName: 'Mansi Sharma',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Single Bed Room',
    },
    {
      bookingId: '1902903',
      clientName: 'Shrishti Goyal',
      bookingStatus: 'Arriving',
      checkInDate: '2023-01-17T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Double Bed Room',
    },
    {
      bookingId: '1432903',
      clientName: 'Muthu swamy venu gopala iyer',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-19T11:01:23Z',
      roomType: 'Triple Bed Room',
    },
    {
      bookingId: '1432904',
      clientName: 'Mansi Sharma',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Single Bed Room',
    },
    {
      bookingId: '1902903',
      clientName: 'Shrishti Goyal',
      bookingStatus: 'Arriving',
      checkInDate: '2023-01-17T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Double Bed Room',
    },
    {
      bookingId: '1432903',
      clientName: 'Muthu swamy venu gopala iyer',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-07T11:01:23Z',
      checkOutDate: '2023-01-09T11:01:23Z',
      roomType: 'Triple Bed Room',
    },
    {
      bookingId: '1432904',
      clientName: 'Mansi Sharma',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Single Bed Room',
    },
    {
      bookingId: '1902903',
      clientName: 'Shrishti Goyal',
      bookingStatus: 'Arriving',
      checkInDate: '2023-01-11T11:01:23Z',
      checkOutDate: '2023-01-13T11:01:23Z',
      roomType: 'Double Bed Room',
    },
    {
      bookingId: '1432903',
      clientName: 'Muthu swamy venu gopala iyer',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-19T11:01:23Z',
      roomType: 'Triple Bed Room',
    },
    {
      bookingId: '1432904',
      clientName: 'Mansi Sharma',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Single Bed Room',
    },
    {
      bookingId: '1902903',
      clientName: 'Shrishti Goyal',
      bookingStatus: 'Arriving',
      checkInDate: '2023-01-17T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Double Bed Room',
    },
    {
      bookingId: '1432903',
      clientName: 'Muthu swamy venu gopala iyer',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-19T11:01:23Z',
      roomType: 'Triple Bed Room',
    },
    {
      bookingId: '1432904',
      clientName: 'Mansi Sharma',
      bookingStatus: 'Cancelled',
      checkInDate: '2023-01-18T11:01:23Z',
      checkOutDate: '2023-01-20T11:01:23Z',
      roomType: 'Single Bed Room',
    },
  ];
  const [rows, setRows] = useState(reservationData);

  useEffect(() => {
    if (filterData.checkInDate !== null || filterData.checkOutDate !== null) {
      if (filterData.checkInDate === null) {
        setRows(reservationData.filter((item) => (moment(item.checkOutDate).format('DD/MM/YYYY') === moment(filterData.checkOutDate).format('DD/MM/YYYY'))));
      } else if (filterData.checkOutDate === null) {
        setRows(reservationData.filter((item) => (moment(item.checkInDate).format('DD/MM/YYYY') === moment(filterData.checkInDate).format('DD/MM/YYYY'))));
      } else {
        setRows(reservationData.filter((item) => (moment(item.checkInDate).format('DD/MM/YYYY') === moment(filterData.checkInDate).format('DD/MM/YYYY')) && (moment(item.checkOutDate).format('DD/MM/YYYY') === moment(filterData.checkOutDate).format('DD/MM/YYYY'))));
      }
    }
    if (filterData.reservationType === 'past') {
      setRows(rows.filter((item) => item.checkOutDate < new Date().toISOString()));
    }
    if (filterData.reservationType === 'ongoing') {
      setRows(rows.filter((item) => item.checkOutDate > new Date().toISOString() && item.checkInDate < new Date().toISOString()));
    }
    if (filterData.reservationType === 'upcoming') {
      setRows(rows.filter((item) => item.checkInDate > new Date().toISOString()));
    }
    if (filterData.checkInDate === null && filterData.checkOutDate === null && filterData.reservationType === 'all') {
      setRows(reservationData);
    }
  }, [filterData]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  return (
    <Box className="ongoingUpcomingReservationsTable" sx={{ width: '100%' }}>
      <Paper sx={{ width: '100%', mb: 2 }}>
        <TableContainer>
          <Table
            sx={{ minWidth: 750 }}
            aria-labelledby="tableTitle"
            size="medium"
          >
            <EnhancedTableHead
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
            />
            <TableBody>
              {stableSort(rows, getComparator(order, orderBy))
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => (
                  <TableRow
                    hover
                    tabIndex={-1}
                    key={index}
                  >
                    <TableCell className="ongoingUpcomingReservationsTable__bookingId">{row.bookingId}</TableCell>
                    <TableCell className="ongoingUpcomingReservationsTable__clientName">
                      {row.clientName}
                    </TableCell>
                    <TableCell className={row.bookingStatus === 'Cancelled' ? 'ongoingUpcomingReservationsTable__bookingCancelled' : 'ongoingUpcomingReservationsTable__bookingActive'}>
                      {row.bookingStatus}
                    </TableCell>
                    <TableCell className="ongoingUpcomingReservationsTable__checkIn">
                      {moment(row.checkInDate).format('DD MMM, YYYY')}
                    </TableCell>
                    <TableCell className="ongoingUpcomingReservationsTable__checkOut">
                      {moment(row.checkOutDate).format('DD MMM, YYYY')}
                    </TableCell>
                    <TableCell className="ongoingUpcomingReservationsTable__roomType">
                      {row.roomType}
                    </TableCell>
                  </TableRow>
                ))}
              {emptyRows > 0 && (
                <TableRow
                  style={{
                    height: (53) * emptyRows,
                  }}
                >
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
    </Box>
  );
}

export default ReservationsTable;
