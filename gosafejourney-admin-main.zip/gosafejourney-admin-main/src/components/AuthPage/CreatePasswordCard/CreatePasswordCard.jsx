import React, { useState } from 'react';
import Input from '../Input/Input';
import './CreatePasswordCard.scss';

function CreatePasswordCard({ formData, handleChange }) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleShowPassword = () => setShowPassword((prevShowPassword) => !prevShowPassword);
  const handleShowConfirmPassword = () => setShowConfirmPassword((prevShowPassword) => !prevShowPassword);

  return (
    <div className="createPassword">
      <h3>Create Password</h3>
      <p className="createPassword__carddesc">Use a minimum of 10 characters, including uppercase letters, lowercase letters & numbers</p>
      <h5>
        Password
        <span>*</span>
      </h5>
      <Input name="password" value={formData.password} handleChange={handleChange} type={showPassword ? 'text' : 'password'} handleShowPassword={handleShowPassword} />
      <h5>
        Confirm Password
        <span>*</span>
      </h5>
      <Input name="confirmPassword" value={formData.confirmPassword} handleChange={handleChange} type={showConfirmPassword ? 'text' : 'password'} handleShowPassword={handleShowConfirmPassword} />
      <button className="createPassword__next" type="submit">Next</button>
      <div className="createPassword__separator" />
      <p>
        By signing in or creating an account, you agree to our
        {' '}
        <span>Terms & Conditions</span>
        {' '}
        and
        {' '}
        <span>Privacy Policy</span>
      </p>
    </div>
  );
}

export default CreatePasswordCard;
