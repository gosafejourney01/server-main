import React from 'react';
import Input from '../Input/Input';
import './SignUpCard.scss';

function SignUpCard({
  formData, setSignUp, setSignIn, handleChange,
}) {
  const continueSignIn = () => {
    setSignUp(false);
    setSignIn(true);
  };

  return (
    <div className="signUp__card">
      <h3>Create your Admin Account</h3>
      <p className="signUp__carddesc" />
      <h5>
        Email Address
        <span>*</span>
      </h5>
      <Input name="email" value={formData.email} handleChange={handleChange} type="email" />
      <button className="signUp__continue" type="submit">Continue</button>
      <div className="signUpCard__separator" />
      <p />
      <button className="signUp__signIn" type="button" onClick={continueSignIn}>Sign-In</button>
      <div className="signUpCard__separator" />
      <p>
        By signing in or creating an account, you agree to our
        {' '}
        <span>Terms & Conditions</span>
        {' '}
        and
        {' '}
        <span>Privacy Policy</span>
      </p>
    </div>
  );
}

export default SignUpCard;
