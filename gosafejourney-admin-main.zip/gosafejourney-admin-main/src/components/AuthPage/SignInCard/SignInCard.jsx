import React, { useState } from 'react';
import Input from '../Input/Input';
import './SignInCard.scss';

function SignInCard({
  setSignIn, setSignUp, handleChange, loading,
}) {
  const [showPassword, setShowPassword] = useState(false);

  const handleShowPassword = () => setShowPassword((prevShowPassword) => !prevShowPassword);

  const continueSignUp = () => {
    setSignIn(false);
    setSignUp(true);
  };

  return (
    <div className="signIn__card">
      <h3>Sign-in to your Admin Account</h3>
      {/* <p className="signIn__carddesc">Sign-in to your account and manage your property</p> */}
      <h5>
        Email Address
        <span>*</span>
      </h5>
      <Input name="email" handleChange={handleChange} type="email" />
      <h5>
        Password
        <span>*</span>
      </h5>
      <Input name="password" handleChange={handleChange} type={showPassword ? 'text' : 'password'} handleShowPassword={handleShowPassword} />
      <button className="signIn__continue" type="submit">Sign-In</button>
      <div className="signInCard__separator" />
      {/* <p>
        Questions about your property or the extranet? Check out
        {' '}
        <span>Partner Help</span>
      </p> */}
      <button className="signIn__signUp" type="button" onClick={continueSignUp}>
        {loading ? 'Loading...' : 'Sign-Up'}
      </button>
      <div className="signInCard__separator" />
      <p>
        By signing in or creating an account, you agree to our
        {' '}
        <span>Terms & Conditions</span>
        {' '}
        and
        {' '}
        <span>Privacy Policy</span>
      </p>
    </div>
  );
}

export default SignInCard;
