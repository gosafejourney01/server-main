import React, { useState } from 'react';
import Input from '../Input/Input';
import './OtpVerificationCard.scss';

function OtpVerificationCard({ handleChange, loading }) {
  const [showOtp, setShowOtp] = useState(false);
  const handleShowOtp = () => setShowOtp((prevShowOtp) => !prevShowOtp);

  return (
    <div className="otpVerification__card">
      <p className="otpVerification__carddesc">Enter OTP Sent to your Email</p>
      <Input name="otp" placeholder="Enter OTP" handleChange={handleChange} type={showOtp ? 'text' : 'password'} handleShowPassword={handleShowOtp} />
      <button className="otpVerification__verify" type="submit">
        {loading ? 'Verifying...' : 'Verify'}
      </button>
      <div className="otpVerificationCard__separator" />
      <p>
        By signing in or creating an account, you agree to our
        {' '}
        <span>Terms & Conditions</span>
        {' '}
        and
        {' '}
        <span>Privacy Policy</span>
      </p>
    </div>
  );
}

export default OtpVerificationCard;
