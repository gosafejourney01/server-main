import React from 'react';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import Input from '../Input/Input';
import './ContactDetailsCard.scss';

function ContactDetailsCard({ formData, handleChange }) {
  return (
    <div className="contactDetails">
      <h3>Contact Details</h3>
      <p className="contact__carddesc">Your full name and phone number are needed to ensure security of your account.</p>
      <h5>
        First Name
        <span>*</span>
      </h5>
      <Input name="firstName" label="First Name" value={formData.firstName} handleChange={handleChange} />
      <h5>
        Last Name
        <span>*</span>
      </h5>
      <Input name="lastName" label="Last Name" value={formData.lastName} handleChange={handleChange} />
      <h5>
        Phone Number
        <span>*</span>
      </h5>
      <PhoneInput
        name="phone"
        country="in"
        onChange={handleChange}
        value={formData.phone}
      />
      <p>Otp will be sent to this mobile number/email for verification</p>
      <button className="contactDetails__next" type="submit">Next</button>
      <div className="contactCard__separator" />
      <p>
        By signing in or creating an account, you agree to our
        {' '}
        <span>Terms & Conditions</span>
        {' '}
        and
        {' '}
        <span>Privacy Policy</span>
      </p>
    </div>
  );
}

export default ContactDetailsCard;
